﻿using LibChromeDotNet;

namespace $safeprojectname$
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            await WebApp.CreateFromAssemblyManifest("web", new App().OnStartupAsync).LaunchAsync();
        }
    }
}